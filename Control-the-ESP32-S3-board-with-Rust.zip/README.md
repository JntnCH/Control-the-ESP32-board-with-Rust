# Control-the-ESP32-board-with-Rust

โปรเจกต์นี้สร้างขึ้นเพื่อควบคุมบอร์ด ESP32-S3 ด้วยภาษา Rust 
พร้อมการเชื่อมต่อ WiFi, MQTT และ OTA Firmware update อัตโนมัติจาก GitHub

## ฟีเจอร์
- ✅ ควบคุม GPIO
- ✅ เชื่อมต่อ WiFi
- ✅ OTA Firmware Update
- ✅ MQTT Subscribe เพื่อควบคุมวาล์ว

## การใช้งาน

```bash
cargo build --release
cargo espflash flash --monitor
```
## toml  สำหรับ ESP32-C3
[target.riscv32imc-esp-espidf]  
runner = "espflash flash --monitor"


## สิ่งที่ต้องทำเพิ่ม
1.เปลี่ยน MQTT Broker:
	•  ในโค้ด ESP32-S3 และ JavaScript ฉันใช้ broker.hivemq.com ซึ่งเป็น public broker
	•  ถ้าคุณมี MQTT broker ของตัวเอง (เช่น Mosquitto) ให้เปลี่ยน mqtt_url ใน Rust และ MQTT_BROKER ใน JavaScript
2.เพิ่มการจัดการข้อผิดพลาด:
	•  ใน JavaScript ถ้า MQTT broker ไม่ทำงาน ควรแจ้งเตือนผู้ใช้
	•  ใน Rust ถ้า MQTT broker ไม่สามารถเชื่อมต่อได้ อาจลอง reconnect