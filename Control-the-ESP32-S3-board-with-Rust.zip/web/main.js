// เชื่อมต่อ MQTT broker
const MQTT_BROKER = "ws://broker.hivemq.com:8000/mqtt"; // ใช้ WebSocket สำหรับ browser
const client = mqtt.connect(MQTT_BROKER);

// เมื่อเชื่อมต่อสำเร็จ
client.on("connect", () => {
  console.log("Connected to MQTT broker");
  // Subscribe เพื่อรับสถานะจาก ESP32
  for (let valveId = 1; valveId <= 6; valveId++) {
    client.subscribe(`valve/${valveId}/status`);
  }
});

// รับสถานะจาก ESP32
client.on("message", (topic, message) => {
  const valveId = parseInt(topic.split("/")[1]);
  const status = message.toString();
  const statusElement = document.getElementById(`status-${valveId}`);
  statusElement.textContent = status === "open" ? "วาล์วเปิดแล้ว" : "วาล์วปิดแล้ว";
});

// ฟังก์ชันควบคุมวาล์ว
function controlValve(valveId, state) {
  const topic = `valve/${valveId}/control`;
  client.publish(topic, state, { qos: 0 }, (err) => {
    if (err) {
      const statusElement = document.getElementById(`status-${valveId}`);
      statusElement.textContent = "ส่งคำสั่งไม่ได้";
    }
  });
}