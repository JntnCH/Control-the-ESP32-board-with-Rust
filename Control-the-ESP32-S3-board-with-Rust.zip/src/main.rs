use esp_idf_sys as _;
use esp_idf_hal::prelude::*;
use esp_idf_hal::gpio::*;
use esp_idf_svc::mqtt::client::*;
use esp_idf_svc::wifi::*;
use esp_idf_svc::netif::*;
use esp_idf_svc::sysloop::*;
use esp_idf_svc::nvs::*;
use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::{thread, time::Duration, str};

// กำหนด GPIO สำหรับวาล์ว 6 ตัว
const VALVE_PINS: [u32; 6] = [23, 22, 21, 19, 18, 5]; // ปรับ GPIO ตามบอร์ดของคุณ

fn main() -> anyhow::Result<()> {
    esp_idf_sys::link_patches();

    let peripherals = Peripherals::take().unwrap();

    // สร้าง HashMap เพื่อเก็บสถานะวาล์ว (thread-safe)
    let valve_states = Arc::new(Mutex::new(HashMap::new()));

    // ตั้งค่า PinDriver สำหรับวาล์ว 6 ตัว
    let mut valves = Vec::new();
    for (i, &pin) in VALVE_PINS.iter().enumerate() {
        let valve = PinDriver::output(peripherals.pins.gpio(pin))?;
        valve.set_low()?; // เริ่มต้นวาล์วในสถานะปิด
        valve_states.lock().unwrap().insert(i + 1, false); // false = ปิด
        valves.push(valve);
    }

    // ตั้งค่า Wi-Fi
    setup_wifi()?;

    // ตั้งค่า MQTT
    let mqtt_url = "mqtt://broker.hivemq.com"; // เปลี่ยนเป็น MQTT broker ของคุณ
    let (mut client, mut conn) = EspMqttClient::new_with_conn(mqtt_url, &Default::default())?;

    // Subscribe to topics for all 6 valves
    for valve_id in 1..=6 {
        let topic = format!("valve/{}/control", valve_id);
        client.subscribe(&topic, QoS::AtMostOnce)?;
    }

    // แชร์สถานะวาล์วและ PinDriver ระหว่าง thread
    let valve_states_clone = Arc::clone(&valve_states);
    let mut valves_clone = valves.clone();

    // Spawn MQTT listener
    thread::spawn(move || {
        while let Some(msg) = conn.next() {
            if let Ok(Event::Received(msg)) = msg {
                let topic = msg.topic().unwrap_or("");
                let data = str::from_utf8(msg.data()).unwrap_or("");
                let (mut client, mut conn) = EspMqttClient::new_with_conn(mqtt_url, &MqttClientConfiguration {
    client_id: Some("esp32-valve-controller"),
    keep_alive_interval: Some(Duration::from_secs(60)),
    ..Default::default()
})?;

                // แยก valve_id จาก topic (เช่น "valve/1/control" -> 1)
                if let Some(valve_id_str) = topic.split('/').nth(1) {
                    if let Ok(valve_id) = valve_id_str.parse::<usize>() {
                        if valve_id >= 1 && valve_id <= 6 {
                            let mut states = valve_states_clone.lock().unwrap();
                            match data {
                                "open" => {
                                    valves_clone[valve_id - 1].set_high().unwrap();
                                    states.insert(valve_id, true);
                                    // Publish status update
                                    let status_topic = format!("valve/{}/status", valve_id);
                                    client.publish(&status_topic, QoS::AtMostOnce, false, "open").unwrap();
                                }
                                "closed" => {
                                    valves_clone[valve_id - 1].set_low().unwrap();
                                    states.insert(valve_id, false);
                                    // Publish status update
                                    let status_topic = format!("valve/{}/status", valve_id);
                                    client.publish(&status_topic, QoS::AtMostOnce, false, "closed").unwrap();
                                }
                                _ => {}
                            }
                        }
                    }
                }
            }
        }
    });

    // Optional: OTA version check
    check_version_and_update("1.0.0")?;

    // รักษาโปรแกรมให้ทำงานต่อไป
    loop {
        thread::sleep(Duration::from_secs(60));
    }
}

// ฟังก์ชันตั้งค่า Wi-Fi
fn setup_wifi() -> anyhow::Result<()> {
    let netif_stack = Arc::new(EspNetif::new(NetworkNamespace::Station)?);
    let sysloop = Arc::new(EspSysLoop::new()?);
    let nvs = Arc::new(EspDefaultNvs::new()?);

    let mut wifi = Wifi::new(netif_stack, sysloop, nvs)?;
    wifi.set_configuration(&Configuration::Client(ClientConfiguration {
        ssid: "YOUR_SSID".into(),
        password: "YOUR_PASSWORD".into(),
        ..Default::default()
    }))?;
    wifi.start()?;
    wifi.connect()?;
    wifi.wait_netif_up()?;

    println!("WiFi connected, IP: {:?}", wifi.sta_netif().get_ip_info()?);
    Ok(())
}

fn check_version_and_update(current_version: &str) -> anyhow::Result<()> {
    let version_url = "https://your-server.com/version.txt";
    let bin_url = "https://your-server.com/firmware.bin";

    let client = EspHttpConnection::new(&Default::default())?;
    let mut res = EspHttpClient::new(client)?.get(version_url)?.submit()?;
    let mut buf = [0u8; 32];
    let len = res.read(&mut buf)?;
    let remote_version = str::from_utf8(&buf[..len])?.trim();

    if remote_version != current_version {
        perform_ota(bin_url)?;
    }
    Ok(())
}

fn perform_ota(bin_url: &str) -> anyhow::Result<()> {
    let conn = EspHttpConnection::new(&Default::default())?;
    let mut res = EspHttpClient::new(conn)?.get(bin_url)?.submit()?;
    let mut ota = esp_idf_svc::ota::EspOtaUpdate::begin()?;

    let mut buf = [0u8; 1024];
    while let Ok(read) = res.read(&mut buf) {
        if read == 0 {
            break;
        }
        ota.write_all(&buf[..read])?;
    }

    ota.finalize()?;
    esp_idf_sys::esp_restart();
    Ok(())
}
// Optional: Firebase Integration (ใช้ REST API)
/*
fn read_valve_status_from_firebase() -> Option<bool> {
    let client = EspHttpConnection::new(&Default::default()).ok()?;
    let mut response = EspHttpClient::new(client)
        .get("https://<PROJECT_ID>.firebaseio.com/valve/status.json")
        .unwrap()
        .submit()
        .unwrap();

    let mut buf = [0u8; 64];
    let len = response.read(&mut buf).unwrap_or(0);
    let data = str::from_utf8(&buf[..len]).unwrap_or("false");
    Some(data.trim() == "true")
}
*/